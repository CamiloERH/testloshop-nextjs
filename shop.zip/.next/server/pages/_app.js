/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/material */ \"@mui/material\");\n/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _themes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../themes */ \"./themes/index.ts\");\n\n\n\n\nfunction MyApp({ Component , pageProps  }) {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ThemeProvider, {\n        theme: _themes__WEBPACK_IMPORTED_MODULE_3__.lightTheme,\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CssBaseline, {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Camilo\\\\Desktop\\\\Code\\\\NextJS\\\\teslo-shop\\\\next-teslo\\\\pages\\\\_app.tsx\",\n                lineNumber: 10,\n                columnNumber: 9\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\Camilo\\\\Desktop\\\\Code\\\\NextJS\\\\teslo-shop\\\\next-teslo\\\\pages\\\\_app.tsx\",\n                lineNumber: 11,\n                columnNumber: 9\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\Camilo\\\\Desktop\\\\Code\\\\NextJS\\\\teslo-shop\\\\next-teslo\\\\pages\\\\_app.tsx\",\n        lineNumber: 9,\n        columnNumber: 5\n    }, this));\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBOEI7QUFFNEI7QUFFcEI7U0FFN0JHLEtBQUssQ0FBQyxDQUFDLENBQUNDLFNBQVMsR0FBRUMsU0FBUyxFQUFXLENBQUMsRUFBRSxDQUFDO0lBQ2xELE1BQU0sNkVBQ0hKLHdEQUFhO1FBQUNLLEtBQUssRUFBR0osK0NBQVU7O3dGQUM1QkYsc0RBQVc7Ozs7O3dGQUNYSSxTQUFTO21CQUFLQyxTQUFTOzs7Ozs7Ozs7Ozs7QUFHaEMsQ0FBQztBQUVELGlFQUFlRixLQUFLIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdGVzbG8tc2hvcC8uL3BhZ2VzL19hcHAudHN4PzJmYmUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnO1xyXG5pbXBvcnQgdHlwZSB7IEFwcFByb3BzIH0gZnJvbSAnbmV4dC9hcHAnO1xyXG5pbXBvcnQgeyBDc3NCYXNlbGluZSwgVGhlbWVQcm92aWRlciB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xyXG5cclxuaW1wb3J0IHsgbGlnaHRUaGVtZSB9IGZyb20gJy4uL3RoZW1lcyc7XHJcblxyXG5mdW5jdGlvbiBNeUFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH06IEFwcFByb3BzKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxUaGVtZVByb3ZpZGVyIHRoZW1lPXsgbGlnaHRUaGVtZX0+XHJcbiAgICAgICAgPENzc0Jhc2VsaW5lIC8+XHJcbiAgICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxyXG4gICAgPC9UaGVtZVByb3ZpZGVyPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTXlBcHBcclxuIl0sIm5hbWVzIjpbIkNzc0Jhc2VsaW5lIiwiVGhlbWVQcm92aWRlciIsImxpZ2h0VGhlbWUiLCJNeUFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyIsInRoZW1lIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./themes/index.ts":
/*!*************************!*\
  !*** ./themes/index.ts ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _light_theme__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./light-theme */ \"./themes/light-theme.ts\");\n/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};\n/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _light_theme__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== \"default\") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _light_theme__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]\n/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi90aGVtZXMvaW5kZXgudHMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7QUFFNkIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly90ZXNsby1zaG9wLy4vdGhlbWVzL2luZGV4LnRzPzVhY2QiXSwic291cmNlc0NvbnRlbnQiOlsiXHJcblxyXG5leHBvcnQgKiBmcm9tICcuL2xpZ2h0LXRoZW1lJzsiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./themes/index.ts\n");

/***/ }),

/***/ "./themes/light-theme.ts":
/*!*******************************!*\
  !*** ./themes/light-theme.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"lightTheme\": () => (/* binding */ lightTheme)\n/* harmony export */ });\n/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @mui/material/styles */ \"@mui/material/styles\");\n/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);\n\nconst lightTheme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.createTheme)({\n    palette: {\n        mode: 'light',\n        primary: {\n            main: '#1E1E1E'\n        },\n        secondary: {\n            main: '#3A64D8'\n        },\n        info: {\n            main: '#fff'\n        }\n    },\n    components: {\n        MuiLink: {\n            defaultProps: {\n                underline: 'none'\n            }\n        },\n        MuiAppBar: {\n            defaultProps: {\n                elevation: 0,\n                position: 'fixed'\n            },\n            styleOverrides: {\n                root: {\n                    backgroundColor: 'white',\n                    height: 60\n                }\n            }\n        },\n        MuiTypography: {\n            styleOverrides: {\n                h1: {\n                    fontSize: 30,\n                    fontWeight: 600\n                },\n                h2: {\n                    fontSize: 20,\n                    fontWeight: 400\n                },\n                subtitle1: {\n                    fontSize: 18,\n                    fontWeight: 600\n                }\n            }\n        },\n        MuiButton: {\n            defaultProps: {\n                variant: 'contained',\n                size: 'small',\n                disableElevation: true,\n                color: 'info'\n            },\n            styleOverrides: {\n                root: {\n                    textTransform: 'none',\n                    boxShadow: 'none',\n                    borderRadius: 10,\n                    \":hover\": {\n                        backgroundColor: 'rgba(0,0,0,0.05)',\n                        transition: 'all 0.3s ease-in-out'\n                    }\n                }\n            }\n        },\n        MuiCard: {\n            defaultProps: {\n                elevation: 0\n            },\n            styleOverrides: {\n                root: {\n                    boxShadow: '0px 5px 5px rgba(0,0,0,0.05)',\n                    borderRadius: '10px'\n                }\n            }\n        }\n    }\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi90aGVtZXMvbGlnaHQtdGhlbWUudHMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQWtEO0FBSTNDLEtBQUssQ0FBQ0MsVUFBVSxHQUFHRCxpRUFBVyxDQUFDLENBQUM7SUFDckNFLE9BQU8sRUFBRSxDQUFDO1FBQ1JDLElBQUksRUFBRSxDQUFPO1FBQ2JDLE9BQU8sRUFBRSxDQUFDO1lBQ1JDLElBQUksRUFBRSxDQUFTO1FBQ2pCLENBQUM7UUFDREMsU0FBUyxFQUFFLENBQUM7WUFDVkQsSUFBSSxFQUFFLENBQVM7UUFDakIsQ0FBQztRQUNERSxJQUFJLEVBQUUsQ0FBQztZQUNMRixJQUFJLEVBQUUsQ0FBTTtRQUNkLENBQUM7SUFDSCxDQUFDO0lBQ0RHLFVBQVUsRUFBRSxDQUFDO1FBQ1hDLE9BQU8sRUFBRSxDQUFDO1lBQ1JDLFlBQVksRUFBRSxDQUFDO2dCQUNiQyxTQUFTLEVBQUUsQ0FBTTtZQUNuQixDQUFDO1FBQ0gsQ0FBQztRQUNEQyxTQUFTLEVBQUUsQ0FBQztZQUNWRixZQUFZLEVBQUUsQ0FBQztnQkFDYkcsU0FBUyxFQUFFLENBQUM7Z0JBQ1pDLFFBQVEsRUFBRSxDQUFPO1lBQ25CLENBQUM7WUFDREMsY0FBYyxFQUFFLENBQUM7Z0JBQ2ZDLElBQUksRUFBRSxDQUFDO29CQUNMQyxlQUFlLEVBQUUsQ0FBTztvQkFDeEJDLE1BQU0sRUFBRSxFQUFFO2dCQUNaLENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQztRQUVEQyxhQUFhLEVBQUUsQ0FBQztZQUNkSixjQUFjLEVBQUUsQ0FBQztnQkFDZkssRUFBRSxFQUFFLENBQUM7b0JBQ0hDLFFBQVEsRUFBRSxFQUFFO29CQUNaQyxVQUFVLEVBQUUsR0FBRztnQkFDakIsQ0FBQztnQkFDREMsRUFBRSxFQUFFLENBQUM7b0JBQ0hGLFFBQVEsRUFBRSxFQUFFO29CQUNaQyxVQUFVLEVBQUUsR0FBRztnQkFDakIsQ0FBQztnQkFDREUsU0FBUyxFQUFFLENBQUM7b0JBQ1ZILFFBQVEsRUFBRSxFQUFFO29CQUNaQyxVQUFVLEVBQUUsR0FBRztnQkFDakIsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO1FBR0RHLFNBQVMsRUFBRSxDQUFDO1lBQ1ZmLFlBQVksRUFBRSxDQUFDO2dCQUNiZ0IsT0FBTyxFQUFFLENBQVc7Z0JBQ3BCQyxJQUFJLEVBQUUsQ0FBTztnQkFDYkMsZ0JBQWdCLEVBQUUsSUFBSTtnQkFDdEJDLEtBQUssRUFBRSxDQUFNO1lBQ2YsQ0FBQztZQUNEZCxjQUFjLEVBQUUsQ0FBQztnQkFDZkMsSUFBSSxFQUFFLENBQUM7b0JBQ0xjLGFBQWEsRUFBRSxDQUFNO29CQUNyQkMsU0FBUyxFQUFFLENBQU07b0JBQ2pCQyxZQUFZLEVBQUUsRUFBRTtvQkFDaEIsQ0FBUSxTQUFFLENBQUM7d0JBQ1RmLGVBQWUsRUFBRSxDQUFrQjt3QkFDbkNnQixVQUFVLEVBQUUsQ0FBc0I7b0JBQ3BDLENBQUM7Z0JBQ0gsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO1FBR0RDLE9BQU8sRUFBRSxDQUFDO1lBQ1J4QixZQUFZLEVBQUUsQ0FBQztnQkFDYkcsU0FBUyxFQUFFLENBQUM7WUFDZCxDQUFDO1lBQ0RFLGNBQWMsRUFBRSxDQUFDO2dCQUNmQyxJQUFJLEVBQUUsQ0FBQztvQkFDTGUsU0FBUyxFQUFFLENBQThCO29CQUN6Q0MsWUFBWSxFQUFFLENBQU07Z0JBQ3RCLENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQztJQUVILENBQUM7QUFDSCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdGVzbG8tc2hvcC8uL3RoZW1lcy9saWdodC10aGVtZS50cz9iMzM5Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZVRoZW1lIH0gZnJvbSAnQG11aS9tYXRlcmlhbC9zdHlsZXMnO1xyXG5pbXBvcnQgeyByZWQsICB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwvY29sb3JzJztcclxuXHJcblxyXG5leHBvcnQgY29uc3QgbGlnaHRUaGVtZSA9IGNyZWF0ZVRoZW1lKHtcclxuICBwYWxldHRlOiB7XHJcbiAgICBtb2RlOiAnbGlnaHQnLFxyXG4gICAgcHJpbWFyeToge1xyXG4gICAgICBtYWluOiAnIzFFMUUxRSdcclxuICAgIH0sXHJcbiAgICBzZWNvbmRhcnk6IHtcclxuICAgICAgbWFpbjogJyMzQTY0RDgnXHJcbiAgICB9LFxyXG4gICAgaW5mbzoge1xyXG4gICAgICBtYWluOiAnI2ZmZidcclxuICAgIH1cclxuICB9LFxyXG4gIGNvbXBvbmVudHM6IHtcclxuICAgIE11aUxpbms6IHtcclxuICAgICAgZGVmYXVsdFByb3BzOiB7XHJcbiAgICAgICAgdW5kZXJsaW5lOiAnbm9uZScsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgTXVpQXBwQmFyOiB7XHJcbiAgICAgIGRlZmF1bHRQcm9wczoge1xyXG4gICAgICAgIGVsZXZhdGlvbjogMCxcclxuICAgICAgICBwb3NpdGlvbjogJ2ZpeGVkJyxcclxuICAgICAgfSxcclxuICAgICAgc3R5bGVPdmVycmlkZXM6IHtcclxuICAgICAgICByb290OiB7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICd3aGl0ZScsXHJcbiAgICAgICAgICBoZWlnaHQ6IDYwXHJcbiAgICAgICAgfSxcclxuICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBNdWlUeXBvZ3JhcGh5OiB7XHJcbiAgICAgIHN0eWxlT3ZlcnJpZGVzOiB7XHJcbiAgICAgICAgaDE6IHtcclxuICAgICAgICAgIGZvbnRTaXplOiAzMCxcclxuICAgICAgICAgIGZvbnRXZWlnaHQ6IDYwMFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgaDI6IHtcclxuICAgICAgICAgIGZvbnRTaXplOiAyMCxcclxuICAgICAgICAgIGZvbnRXZWlnaHQ6IDQwMFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc3VidGl0bGUxOiB7XHJcbiAgICAgICAgICBmb250U2l6ZTogMTgsXHJcbiAgICAgICAgICBmb250V2VpZ2h0OiA2MDBcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0sXHJcblxyXG5cclxuICAgIE11aUJ1dHRvbjoge1xyXG4gICAgICBkZWZhdWx0UHJvcHM6IHtcclxuICAgICAgICB2YXJpYW50OiAnY29udGFpbmVkJyxcclxuICAgICAgICBzaXplOiAnc21hbGwnLFxyXG4gICAgICAgIGRpc2FibGVFbGV2YXRpb246IHRydWUsXHJcbiAgICAgICAgY29sb3I6ICdpbmZvJ1xyXG4gICAgICB9LFxyXG4gICAgICBzdHlsZU92ZXJyaWRlczoge1xyXG4gICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgIHRleHRUcmFuc2Zvcm06ICdub25lJyxcclxuICAgICAgICAgIGJveFNoYWRvdzogJ25vbmUnLFxyXG4gICAgICAgICAgYm9yZGVyUmFkaXVzOiAxMCxcclxuICAgICAgICAgIFwiOmhvdmVyXCI6IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiAncmdiYSgwLDAsMCwwLjA1KScsXHJcbiAgICAgICAgICAgIHRyYW5zaXRpb246ICdhbGwgMC4zcyBlYXNlLWluLW91dCdcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0sXHJcblxyXG5cclxuICAgIE11aUNhcmQ6IHtcclxuICAgICAgZGVmYXVsdFByb3BzOiB7XHJcbiAgICAgICAgZWxldmF0aW9uOiAwXHJcbiAgICAgIH0sXHJcbiAgICAgIHN0eWxlT3ZlcnJpZGVzOiB7XHJcbiAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgYm94U2hhZG93OiAnMHB4IDVweCA1cHggcmdiYSgwLDAsMCwwLjA1KScsXHJcbiAgICAgICAgICBib3JkZXJSYWRpdXM6ICcxMHB4JyxcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIFxyXG4gIH1cclxufSk7Il0sIm5hbWVzIjpbImNyZWF0ZVRoZW1lIiwibGlnaHRUaGVtZSIsInBhbGV0dGUiLCJtb2RlIiwicHJpbWFyeSIsIm1haW4iLCJzZWNvbmRhcnkiLCJpbmZvIiwiY29tcG9uZW50cyIsIk11aUxpbmsiLCJkZWZhdWx0UHJvcHMiLCJ1bmRlcmxpbmUiLCJNdWlBcHBCYXIiLCJlbGV2YXRpb24iLCJwb3NpdGlvbiIsInN0eWxlT3ZlcnJpZGVzIiwicm9vdCIsImJhY2tncm91bmRDb2xvciIsImhlaWdodCIsIk11aVR5cG9ncmFwaHkiLCJoMSIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsImgyIiwic3VidGl0bGUxIiwiTXVpQnV0dG9uIiwidmFyaWFudCIsInNpemUiLCJkaXNhYmxlRWxldmF0aW9uIiwiY29sb3IiLCJ0ZXh0VHJhbnNmb3JtIiwiYm94U2hhZG93IiwiYm9yZGVyUmFkaXVzIiwidHJhbnNpdGlvbiIsIk11aUNhcmQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./themes/light-theme.ts\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@mui/material":
/*!********************************!*\
  !*** external "@mui/material" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material");

/***/ }),

/***/ "@mui/material/styles":
/*!***************************************!*\
  !*** external "@mui/material/styles" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/styles");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();